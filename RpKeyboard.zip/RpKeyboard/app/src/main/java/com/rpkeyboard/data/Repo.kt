package com.rpkeyboard.data

import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

data class ImpTemplate(val name: String, val mode: String, val text: String, val favorite: Boolean)
data class ImpFolder(val name: String, val folders: List<ImpFolder>, val templates: List<ImpTemplate>)

fun ImpFolder.countTemplates(): Int = templates.size + folders.sumOf { it.countTemplates() }
fun ImpFolder.countFolders(): Int = folders.size + folders.sumOf { it.countFolders() }

fun descendants(all: List<FolderEntity>, id: Long): Set<Long> {
    val out = mutableSetOf<Long>()
    val queue = ArrayDeque<Long>()
    queue.add(id)
    while (queue.isNotEmpty()) {
        val c = queue.removeFirst()
        all.filter { it.parentId == c }.forEach { if (out.add(it.id)) queue.add(it.id) }
    }
    return out
}

class Repo(private val dao: RpDao) {
    val folders: Flow<List<FolderEntity>> = dao.allFolders()
    val templates: Flow<List<TemplateEntity>> = dao.allTemplates()
    val recents: Flow<List<TemplateEntity>> = dao.recents()

    suspend fun isEmpty() = dao.folderCount() == 0

    // ---------- folders ----------
    suspend fun addFolder(parent: Long?, name: String): Long =
        dao.insertFolder(FolderEntity(parentId = parent, name = name.trim(), position = dao.nextFolderPos(parent)))

    suspend fun renameFolder(f: FolderEntity, name: String) = dao.updateFolder(f.copy(name = name.trim()))

    suspend fun deleteFolder(f: FolderEntity) = dao.deleteFolder(f)

    suspend fun moveFolderTo(f: FolderEntity, parent: Long?) {
        if (parent != null) {
            val all = dao.allFoldersOnce()
            if (parent == f.id || parent in descendants(all, f.id)) return
        }
        dao.updateFolder(f.copy(parentId = parent, position = dao.nextFolderPos(parent)))
    }

    suspend fun shiftFolder(f: FolderEntity, dir: Int) {
        val sib = dao.foldersOnce(f.parentId).toMutableList()
        val i = sib.indexOfFirst { it.id == f.id }
        val j = i + dir
        if (i < 0 || j !in sib.indices) return
        java.util.Collections.swap(sib, i, j)
        sib.forEachIndexed { k, s -> if (s.position != k) dao.updateFolder(s.copy(position = k)) }
    }

    // ---------- templates ----------
    suspend fun saveTemplate(t: TemplateEntity) {
        if (t.id == 0L) dao.insertTemplate(t.copy(position = dao.nextTemplatePos(t.folderId)))
        else dao.updateTemplate(t)
    }

    suspend fun deleteTemplate(t: TemplateEntity) = dao.deleteTemplate(t)

    suspend fun moveTemplateTo(t: TemplateEntity, folder: Long?) =
        dao.updateTemplate(t.copy(folderId = folder, position = dao.nextTemplatePos(folder)))

    suspend fun shiftTemplate(t: TemplateEntity, dir: Int) {
        val sib = dao.templatesOnce(t.folderId).toMutableList()
        val i = sib.indexOfFirst { it.id == t.id }
        val j = i + dir
        if (i < 0 || j !in sib.indices) return
        java.util.Collections.swap(sib, i, j)
        sib.forEachIndexed { k, s -> if (s.position != k) dao.updateTemplate(s.copy(position = k)) }
    }

    suspend fun toggleFav(t: TemplateEntity) = dao.setFavorite(t.id, !t.favorite)
    suspend fun touch(id: Long) = dao.setLastUsed(id, System.currentTimeMillis())
    suspend fun clearRecents() = dao.clearRecents()

    // ---------- JSON ----------
    suspend fun exportJson(): String {
        val fs = dao.allFoldersOnce()
        val ts = dao.allTemplatesOnce()
        fun node(parent: Long?, o: JSONObject): JSONObject {
            val fa = JSONArray()
            fs.filter { it.parentId == parent }.forEach { f -> fa.put(node(f.id, JSONObject().put("name", f.name))) }
            val ta = JSONArray()
            ts.filter { it.folderId == parent }.forEach { t ->
                ta.put(
                    JSONObject().put("name", t.name).put("mode", t.mode)
                        .put("text", t.text).put("favorite", t.favorite)
                )
            }
            return o.put("folders", fa).put("templates", ta)
        }
        return node(null, JSONObject().put("version", 1)).toString(2)
    }

    fun parseLibrary(json: String): ImpFolder {
        val root = try {
            JSONObject(json)
        } catch (e: JSONException) {
            throw IllegalArgumentException("Файл не является корректным JSON")
        }
        if (!root.has("folders") && !root.has("templates")) {
            throw IllegalArgumentException("В файле нет поля «folders»")
        }
        return parseNode("", root, "корень")
    }

    private fun parseNode(name: String, o: JSONObject, where: String): ImpFolder {
        val fs = o.optJSONArray("folders")
        val ts = o.optJSONArray("templates")
        val folders = (0 until (fs?.length() ?: 0)).map { i ->
            val f = fs!!.optJSONObject(i)
                ?: throw IllegalArgumentException("Папка №${i + 1} в «$where» имеет неверный формат")
            val n = f.optString("name", "")
            if (n.isBlank()) throw IllegalArgumentException("У папки №${i + 1} в «$where» нет названия")
            parseNode(n, f, n)
        }
        val templates = (0 until (ts?.length() ?: 0)).map { i ->
            val t = ts!!.optJSONObject(i)
                ?: throw IllegalArgumentException("Шаблон №${i + 1} в «$where» имеет неверный формат")
            val n = t.optString("name", "")
            val x = t.optString("text", "")
            if (n.isBlank() || x.isBlank()) {
                throw IllegalArgumentException("У шаблона №${i + 1} в «$where» нет названия или текста")
            }
            ImpTemplate(n, t.optString("mode", "chat").ifBlank { "chat" }, x, t.optBoolean("favorite", false))
        }
        return ImpFolder(name, folders, templates)
    }

    private suspend fun existingKeys(): Set<String> {
        val fs = dao.allFoldersOnce()
        val byId = fs.associateBy { it.id }
        fun path(f: FolderEntity): String = f.parentId?.let { p -> path(byId.getValue(p)) + "/" + f.name } ?: ("/" + f.name)
        val paths = fs.associate { it.id to path(it) }
        return dao.allTemplatesOnce().map { t -> "${t.folderId?.let { paths[it] } ?: ""}|${t.name}|${t.text}" }.toSet()
    }

    suspend fun countDuplicates(root: ImpFolder): Int {
        val existing = existingKeys()
        var n = 0
        fun walk(f: ImpFolder, path: String) {
            f.templates.forEach { if ("$path|${it.name}|${it.text}" in existing) n++ }
            f.folders.forEach { walk(it, "$path/${it.name}") }
        }
        walk(root, "")
        return n
    }

    suspend fun import(root: ImpFolder, skipDuplicates: Boolean, replace: Boolean) {
        if (replace) {
            dao.clearTemplates()
            dao.clearFolders()
        }
        val seen = if (skipDuplicates && !replace) existingKeys().toMutableSet() else mutableSetOf()
        suspend fun walk(f: ImpFolder, parent: Long?, path: String) {
            for (t in f.templates) {
                val key = "$path|${t.name}|${t.text}"
                if (skipDuplicates && key in seen) continue
                seen.add(key)
                dao.insertTemplate(
                    TemplateEntity(
                        folderId = parent, name = t.name, text = t.text, mode = t.mode,
                        favorite = t.favorite, position = dao.nextTemplatePos(parent)
                    )
                )
            }
            for (sub in f.folders) {
                val id = dao.foldersOnce(parent).firstOrNull { it.name == sub.name }?.id
                    ?: dao.insertFolder(FolderEntity(parentId = parent, name = sub.name, position = dao.nextFolderPos(parent)))
                walk(sub, id, "$path/${sub.name}")
            }
        }
        walk(root, null, "")
    }

    // ---------- стартовая библиотека ----------
    private fun t(n: String, m: String, x: String) = ImpTemplate(n, m, x, false)
    private fun f(n: String, vararg ts: ImpTemplate) = ImpFolder(n, emptyList(), ts.toList())

    suspend fun seed() {
        val tree = ImpFolder(
            "", listOf(
                f(
                    "Документы",
                    t("Паспорт в кармане", "event", "Паспорт в кармане."),
                    t("Достал паспорт", "action", "Сунул руку в карман и достал паспорт."),
                    t("Передал паспорт", "action", "Передал паспорт человеку напротив."),
                    t("Проверил паспорт", "action", "Внимательно проверил паспорт."),
                    t("Достал ВУ", "action", "Достал водительское удостоверение из кармана.")
                ),
                f(
                    "Полиция",
                    t("Проверка документов", "action", "Попросил предъявить документы."),
                    t("Задержание", "action", "Заломил руку за спину."),
                    t("Наручники", "action", "Достал наручники и надел их на задержанного."),
                    t("Обыск", "try", "Провести обыск."),
                    t("Допрос", "chat", "Назовите ваше имя и цель визита.")
                ),
                f(
                    "ГИБДД",
                    t("Остановка автомобиля", "action", "Поднял жезл, подавая сигнал остановиться."),
                    t("Проверка документов", "action", "Попросил водителя предъявить документы."),
                    t("Проверка багажника", "try", "Осмотреть багажник."),
                    t("Проверка автомобиля", "action", "Осмотрел автомобиль снаружи.")
                ),
                f(
                    "Медицина",
                    t("Осмотр", "action", "Осмотрел пациента."),
                    t("Первая помощь", "action", "Начал оказывать первую помощь."),
                    t("Госпитализация", "action", "Помог уложить пострадавшего на носилки.")
                ),
                f(
                    "Гражданская жизнь",
                    t("Покупка", "chat", "Здравствуйте, я хотел бы купить."),
                    t("Продажа", "chat", "Предлагаю купить, цена обсуждается."),
                    t("Общение", "chat", "Добрый день.")
                )
            ), emptyList()
        )
        import(tree, skipDuplicates = false, replace = false)
    }
}
