package com.rpkeyboard.ime

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.pointerInput

/** Мгновенное нажатие без ripple-анимации. */
fun Modifier.tap(onLong: (() -> Unit)? = null, onTap: () -> Unit): Modifier = composed {
    val t = rememberUpdatedState(onTap)
    val l = rememberUpdatedState(onLong)
    pointerInput(Unit) {
        detectTapGestures(onLongPress = { l.value?.invoke() }, onTap = { t.value() })
    }
}
