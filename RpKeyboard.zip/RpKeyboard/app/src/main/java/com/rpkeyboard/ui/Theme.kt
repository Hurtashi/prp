package com.rpkeyboard.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun RpTheme(dark: Boolean, content: @Composable () -> Unit) {
    val cs = if (dark) {
        darkColorScheme(
            primary = Color(0xFF8AA4FF),
            onPrimary = Color(0xFF0B1330),
            background = Color(0xFF121316),
            onBackground = Color(0xFFE6E6EA),
            surface = Color(0xFF1B1C20),
            onSurface = Color(0xFFE6E6EA),
            surfaceVariant = Color(0xFF2B2D35),
            onSurfaceVariant = Color(0xFFB8BAC4),
            secondaryContainer = Color(0xFF3A3F55),
            onSecondaryContainer = Color(0xFFE0E4FF)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF3B5BDB),
            surfaceVariant = Color(0xFFE6E8F0),
            secondaryContainer = Color(0xFFD5DBF5)
        )
    }
    MaterialTheme(colorScheme = cs, content = content)
}
