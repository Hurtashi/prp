package com.rpkeyboard

import android.app.Application
import androidx.room.Room
import com.rpkeyboard.data.AppDb
import com.rpkeyboard.data.Prefs
import com.rpkeyboard.data.Repo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RpApp : Application() {
    val prefs by lazy { Prefs(this) }
    val repo by lazy { Repo(Room.databaseBuilder(this, AppDb::class.java, "rp.db").build().dao()) }

    override fun onCreate() {
        super.onCreate()
        CoroutineScope(Dispatchers.IO).launch {
            if (!prefs.seeded) {
                if (repo.isEmpty()) repo.seed()
                prefs.seeded = true
            }
        }
    }
}
