package com.rpkeyboard.data

import android.content.Context

val PRESET_MODES = listOf("event", "action", "try", "chat")

fun modeLabel(m: String): String = when (m) {
    "event" -> "Событие"
    "action" -> "Действие"
    "try" -> "Попытка"
    "chat" -> "Обычный чат"
    else -> m
}

data class KbSettings(
    val dark: Boolean = true,
    val heightDp: Int = 300,
    val btnDp: Int = 48,
    val textSp: Int = 14,
    val columns: Int = 2,
    val hintMode: Boolean = true,
    val showRecents: Boolean = true,
    val showFavorites: Boolean = true
)

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("rp_settings", Context.MODE_PRIVATE)

    fun load() = KbSettings(
        dark = p.getBoolean("dark", true),
        heightDp = p.getInt("height", 300),
        btnDp = p.getInt("btn", 48),
        textSp = p.getInt("text", 14),
        columns = p.getInt("cols", 2),
        hintMode = p.getBoolean("hint", true),
        showRecents = p.getBoolean("recents", true),
        showFavorites = p.getBoolean("favs", true)
    )

    fun save(s: KbSettings) {
        p.edit()
            .putBoolean("dark", s.dark)
            .putInt("height", s.heightDp)
            .putInt("btn", s.btnDp)
            .putInt("text", s.textSp)
            .putInt("cols", s.columns)
            .putBoolean("hint", s.hintMode)
            .putBoolean("recents", s.showRecents)
            .putBoolean("favs", s.showFavorites)
            .apply()
    }

    var lastFolder: Long?
        get() = p.getLong("lastFolder", -1L).takeIf { it >= 0 }
        set(v) { p.edit().putLong("lastFolder", v ?: -1L).apply() }

    var seeded: Boolean
        get() = p.getBoolean("seeded", false)
        set(v) { p.edit().putBoolean("seeded", v).apply() }
}
