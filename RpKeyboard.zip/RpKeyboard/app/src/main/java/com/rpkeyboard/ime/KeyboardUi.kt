package com.rpkeyboard.ime

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rpkeyboard.data.FolderEntity
import com.rpkeyboard.data.KbSettings
import com.rpkeyboard.data.Repo
import com.rpkeyboard.data.TemplateEntity
import com.rpkeyboard.data.modeLabel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class Screen { FOLDER, FAVORITES, RECENTS, SEARCH }

class KbState {
    var settings by mutableStateOf(KbSettings())
    var rp by mutableStateOf(false)
    var password by mutableStateOf(false)
    var screen by mutableStateOf(Screen.FOLDER)
    var folderId by mutableStateOf<Long?>(null)
    var query by mutableStateOf("")
    var hint by mutableStateOf<String?>(null)

    fun back(folders: List<FolderEntity>) {
        if (screen != Screen.FOLDER) {
            screen = Screen.FOLDER
            query = ""
        } else {
            val id = folderId ?: return
            folderId = folders.firstOrNull { it.id == id }?.parentId
        }
    }

    fun title(folders: List<FolderEntity>): String = when (screen) {
        Screen.FAVORITES -> "★ Избранное"
        Screen.RECENTS -> "🕘 Недавние"
        Screen.SEARCH -> "Поиск"
        Screen.FOLDER -> folderId?.let { id -> folders.firstOrNull { it.id == id }?.name } ?: "Библиотека"
    }
}

class KeyActions(
    val type: (String) -> Unit,
    val backspace: () -> Unit,
    val enter: () -> Unit,
    val insert: (TemplateEntity) -> Unit,
    val toggleFav: (TemplateEntity) -> Unit,
    val openSettings: () -> Unit
)

sealed class GridItem(val key: String) {
    class F(val f: FolderEntity) : GridItem("f${f.id}")
    class V(val screen: Screen, val label: String) : GridItem("v${screen.name}")
    class T(val t: TemplateEntity) : GridItem("t${t.id}")
}

@Composable
fun KeyboardRoot(ks: KbState, repo: Repo, act: KeyActions) {
    val s = ks.settings
    val folders by repo.folders.collectAsState(initial = emptyList())
    val templates by repo.templates.collectAsState(initial = emptyList())
    val recents by repo.recents.collectAsState(initial = emptyList())
    val showRp = ks.rp && !ks.password

    Column(
        Modifier
            .fillMaxWidth()
            .height(s.heightDp.dp)
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 4.dp, vertical = 3.dp)
    ) {
        TopBar(ks, showRp, folders, act)
        Spacer(Modifier.height(3.dp))
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (showRp) RpPanel(ks, folders, templates, recents, act)
            else TypingKeyboard(Modifier.fillMaxSize(), act.type, act.backspace, act.enter)
        }
    }
}

@Composable
private fun TopBar(ks: KbState, showRp: Boolean, folders: List<FolderEntity>, act: KeyActions) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().height(40.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!ks.password) BarBtn(if (ks.rp) "ABC" else "RP", true) { ks.rp = !ks.rp }
        if (showRp) {
            BarBtn("🔍") {
                ks.screen = if (ks.screen == Screen.SEARCH) Screen.FOLDER else Screen.SEARCH
                ks.query = ""
            }
            BarBtn("★") { ks.screen = Screen.FAVORITES }
            BarBtn("←") { ks.back(folders) }
            Text(
                ks.title(folders),
                Modifier.weight(1f).padding(horizontal = 6.dp),
                fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = cs.onSurfaceVariant
            )
        } else {
            Spacer(Modifier.weight(1f))
        }
        BarBtn("⚙") { act.openSettings() }
    }
}

@Composable
private fun BarBtn(label: String, accent: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .width(44.dp)
            .fillMaxHeight()
            .clip(RoundedCornerShape(10.dp))
            .background(if (accent) cs.primary else cs.surfaceVariant)
            .tap { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = if (accent) cs.onPrimary else cs.onSurface)
    }
}

@Composable
private fun RpPanel(
    ks: KbState,
    folders: List<FolderEntity>,
    templates: List<TemplateEntity>,
    recents: List<TemplateEntity>,
    act: KeyActions
) {
    val s = ks.settings
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        val h = ks.hint
        if (h != null && s.hintMode) {
            Text(
                h, Modifier.fillMaxWidth().padding(bottom = 2.dp, start = 4.dp),
                fontSize = 12.sp, color = cs.primary, maxLines = 1
            )
        }
        if (ks.screen == Screen.SEARCH) {
            Box(
                Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(8.dp))
                    .background(cs.surfaceVariant).padding(horizontal = 10.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    if (ks.query.isEmpty()) "Поиск по шаблонам и папкам…" else ks.query,
                    fontSize = 14.sp,
                    color = if (ks.query.isEmpty()) cs.onSurfaceVariant else cs.onSurface,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(3.dp))
            val results = remember(ks.query, templates, folders) { search(ks.query, templates, folders) }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                CardGrid(results.map { GridItem.T(it) }, ks, act)
            }
            Spacer(Modifier.height(3.dp))
            TypingKeyboard(
                Modifier.fillMaxWidth().height(172.dp),
                { ks.query += it },
                { ks.query = ks.query.dropLast(1) },
                null
            )
        } else {
            val items = remember(ks.screen, ks.folderId, folders, templates, recents, s.showFavorites, s.showRecents) {
                when (ks.screen) {
                    Screen.FAVORITES -> templates.filter { it.favorite }.map { GridItem.T(it) }
                    Screen.RECENTS -> recents.map { GridItem.T(it) }
                    else -> buildList<GridItem> {
                        if (ks.folderId == null) {
                            if (s.showFavorites) add(GridItem.V(Screen.FAVORITES, "★ Избранное"))
                            if (s.showRecents) add(GridItem.V(Screen.RECENTS, "🕘 Недавние"))
                        }
                        folders.filter { it.parentId == ks.folderId }.forEach { add(GridItem.F(it)) }
                        templates.filter { it.folderId == ks.folderId }.forEach { add(GridItem.T(it)) }
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxWidth()) { CardGrid(items, ks, act) }
        }
    }
}

private fun search(q: String, templates: List<TemplateEntity>, folders: List<FolderEntity>): List<TemplateEntity> {
    val query = q.trim().lowercase()
    if (query.isEmpty()) return emptyList()
    val names = folders.associate { it.id to it.name.lowercase() }
    return templates.filter {
        it.name.lowercase().contains(query) ||
            it.text.lowercase().contains(query) ||
            (it.folderId?.let { id -> names[id] }?.contains(query) == true)
    }
}

@Composable
private fun CardGrid(list: List<GridItem>, ks: KbState, act: KeyActions) {
    val s = ks.settings
    LazyVerticalGrid(
        columns = GridCells.Fixed(s.columns),
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        items(list, key = { it.key }) { item ->
            when (item) {
                is GridItem.F -> Card("📁 ${item.f.name}", null, true, s, {
                    ks.folderId = item.f.id
                    ks.screen = Screen.FOLDER
                }, null)
                is GridItem.V -> Card(item.label, null, true, s, { ks.screen = item.screen }, null)
                is GridItem.T -> Card(
                    (if (item.t.favorite) "★ " else "") + item.t.name,
                    if (s.hintMode) modeLabel(item.t.mode) else null,
                    false, s,
                    { act.insert(item.t) },
                    { act.toggleFav(item.t) }
                )
            }
        }
    }
}

@Composable
private fun Card(
    text: String, sub: String?, accent: Boolean, s: KbSettings,
    onTap: () -> Unit, onLong: (() -> Unit)?
) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = s.btnDp.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (accent) cs.secondaryContainer else cs.surfaceVariant)
            .tap(onLong, onTap)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text, fontSize = s.textSp.sp,
            color = if (accent) cs.onSecondaryContainer else cs.onSurface,
            maxLines = 3, overflow = TextOverflow.Ellipsis
        )
        if (sub != null) Text(sub, fontSize = (s.textSp - 4).coerceAtLeast(9).sp, color = cs.primary)
    }
}

// ---------------------------------------------------------------- клавиатура для набора

private val RU = listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
private val EN = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
private val SYM = listOf("1234567890", "@#₽%&-+()", "!?:;\"'/*=")

@Composable
fun TypingKeyboard(modifier: Modifier, onChar: (String) -> Unit, onBack: () -> Unit, onEnter: (() -> Unit)?) {
    var ru by remember { mutableStateOf(true) }
    var shift by remember { mutableStateOf(false) }
    var sym by remember { mutableStateOf(false) }
    val rows = if (sym) SYM else if (ru) RU else EN

    Column(modifier, verticalArrangement = Arrangement.spacedBy(3.dp)) {
        rows.forEachIndexed { i, row ->
            Row(
                Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                if (i == 2) {
                    if (sym) Spacer(Modifier.weight(1.3f))
                    else Key(if (shift) "⬆" else "⇧", 1.3f, true) { shift = !shift }
                }
                row.forEach { c ->
                    val out = if (shift && !sym) c.toString().uppercase() else c.toString()
                    Key(out) {
                        onChar(out)
                        if (shift) shift = false
                    }
                }
                if (i == 2) BackKey(1.3f, onBack)
            }
        }
        Row(
            Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Key(if (sym) "АБВ" else "123", 1.3f, true) { sym = !sym }
            Key(if (ru) "RU" else "EN", 1f, true) {
                ru = !ru
                sym = false
            }
            Key(",") { onChar(",") }
            Key("пробел", 4f) { onChar(" ") }
            Key(".") { onChar(".") }
            if (onEnter != null) Key("↵", 1.3f, true) { onEnter() }
        }
    }
}

@Composable
private fun RowScope.Key(label: String, weight: Float = 1f, special: Boolean = false, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(if (special) cs.secondaryContainer else cs.surfaceVariant)
            .tap { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, fontSize = 18.sp, maxLines = 1,
            color = if (special) cs.onSecondaryContainer else cs.onSurface
        )
    }
}

@Composable
private fun RowScope.BackKey(weight: Float, onBack: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val cb = rememberUpdatedState(onBack)
    val scope = rememberCoroutineScope()
    Box(
        Modifier
            .weight(weight)
            .fillMaxHeight()
            .clip(RoundedCornerShape(8.dp))
            .background(cs.secondaryContainer)
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    cb.value()
                    val job = scope.launch {
                        delay(400)
                        while (true) {
                            cb.value()
                            delay(55)
                        }
                    }
                    tryAwaitRelease()
                    job.cancel()
                })
            },
        contentAlignment = Alignment.Center
    ) {
        Text("⌫", fontSize = 18.sp, color = cs.onSecondaryContainer)
    }
}
